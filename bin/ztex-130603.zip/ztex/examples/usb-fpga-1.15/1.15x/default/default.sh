../../../../java/FWLoader -c -uu default.ihx -ue default.ihx

