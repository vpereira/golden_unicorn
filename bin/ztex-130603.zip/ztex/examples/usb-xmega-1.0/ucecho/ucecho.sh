#make -C ../../../java distclean all || exit
#make distclean all || exit
#make || exit
java -cp UCEcho.jar UCEcho $@
