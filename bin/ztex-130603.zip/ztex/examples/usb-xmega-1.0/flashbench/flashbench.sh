#make -C ../../ztex/java distclean all || exit
#make distclean all || exit
java -cp FlashBench.jar FlashBench $@
